/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/
 */
#pragma once

#include <ReactCommon/CallInvoker.h>
#include <jsi/jsi.h>

#include <functional>
#include <memory>
#include <string>

namespace ubrn::jsi_player {

// Maps the `name` a generated binding passes to `uniffi.open({ name })` onto
// the path the player hands to dlopen. Each host knows its own layout: a
// soname on Android, an embedded framework on iOS, a directory on the host.
using Resolver = std::function<std::string(const std::string &name)>;

// Host-only teardown, with no JSI access. May be called from another thread
// ONLY after the host has stopped and joined the JS queue: no callback can
// still execute, and none of its queued tasks can execute in the future.
// Idempotent; does not keep the JS runtime or its player root alive.
using RuntimeCleanup = std::function<void()>;

// Installs `globalThis.uniffi` on `rt`. Call once per JS runtime.
// Hosts that destroy on their JS thread can ignore the returned cleanup.
RuntimeCleanup install(facebook::jsi::Runtime &rt,
             std::shared_ptr<facebook::react::CallInvoker> callInvoker,
             Resolver resolver);

} // namespace ubrn::jsi_player
