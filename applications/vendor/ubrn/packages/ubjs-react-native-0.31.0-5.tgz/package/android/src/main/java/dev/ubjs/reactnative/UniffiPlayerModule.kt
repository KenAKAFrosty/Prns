/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/
 */
package dev.ubjs.reactnative

import android.util.Log
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.module.annotations.ReactModule
import com.facebook.react.turbomodule.core.interfaces.CallInvokerHolder

@ReactModule(name = UniffiPlayerModule.NAME)
class UniffiPlayerModule(reactContext: ReactApplicationContext) :
  NativeUniffiPlayerSpec(reactContext) {

  private var nativeToken: Long = 0
  private var installedJSThread: Thread? = null
  private var invalidated = false

  override fun getName(): String = NAME

  // Implemented in cpp-adapter.cpp: installs `globalThis.uniffi` on the runtime.
  external fun nativeInstall(runtimePointer: Long, callInvoker: CallInvokerHolder): Long
  external fun nativeRelease(token: Long, jsQueueStopped: Boolean)

  @Synchronized
  override fun install(): Boolean {
    if (invalidated) return false
    if (nativeToken != 0L) return true
    val context = reactApplicationContext
    check(context.isOnJSQueueThread) { "UniffiPlayer.install must run on the JS thread" }
    nativeToken = nativeInstall(
      context.javaScriptContextHolder!!.get(),
      context.jsCallInvokerHolder!!,
    )
    installedJSThread = Thread.currentThread()
    return nativeToken != 0L
  }

  @Synchronized
  override fun invalidate() {
    invalidated = true
    val token = nativeToken
    nativeToken = 0
    val thread = installedJSThread
    installedJSThread = null
    if (token != 0L) {
      // RN's ReactInstance.destroy quits and joins its queues before calling
      // TurboModuleManager.invalidate, then destroys Hermes on the host thread.
      // Verify the actual installed JS thread terminated; never infer that an
      // arbitrary module invalidation or HostObject GC is safe to abort.
      val queueStopped = thread != null && !thread.isAlive
      if (!queueStopped) {
        Log.e(NAME, "JS queue still alive during invalidation; retaining native work for safety")
      }
      nativeRelease(token, queueStopped)
      if (queueStopped) {
        Log.d(NAME, "Native teardown completed after JS thread termination")
      }
    }
    super.invalidate()
  }

  companion object {
    const val NAME = "UniffiPlayer"

    init {
      System.loadLibrary("ubrn_jsi_player")
    }
  }
}
